

<?php $__env->startSection('title'); ?>
about
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
        ini adalah halaman about
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUZ R1 19\Documents\aplikasi_web1\resources\views/about.blade.php ENDPATH**/ ?>